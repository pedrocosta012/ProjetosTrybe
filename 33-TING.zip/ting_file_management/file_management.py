def txt_importer(path_file):
    """Aqui irá sua implementação"""
