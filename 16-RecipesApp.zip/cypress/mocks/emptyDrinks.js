const emptyDrinks = { 'drinks': null };

module.exports = emptyDrinks;
