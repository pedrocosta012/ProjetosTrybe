const types = [
  { columnName: 'id', columnType: 'INT' },
  { columnName: 'sale_id', columnType: 'INT' },
  { columnName: 'product_id', columnType: 'INT' },
  { columnName: 'quantity', columnType: 'INT' }
];

module.exports = types
