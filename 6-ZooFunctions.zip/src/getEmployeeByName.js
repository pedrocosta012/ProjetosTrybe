const data = require('../data/zoo_data');

function getEmployeeByName(employeeName) {
  // seu código aqui
}

module.exports = getEmployeeByName;
