import * as Races from '../../src/Races';
const dwarf = new Races.Dwarf('', 100);