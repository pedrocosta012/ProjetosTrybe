import React from 'react';
import './App.css';

function App() {
  return (
    <span>Hello, App!</span>
  );
}

export default App;
