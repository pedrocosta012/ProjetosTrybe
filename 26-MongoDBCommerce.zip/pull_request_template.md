### Preparação:

#### Assistir Aulas
- [ ] 11.1
- [ ] 11.2
- [ ] 11.3
- [ ] 11.4
- [ ] 11.5


### Garantir que assimilei os seguintes conteúdos**

- [ ] [Método find()](https://app.betrybe.com/learn/course/5e938f69-6e32-43b3-9685-c936530fd326/module/94d0e996-1827-4fbc-bc24-c99fb592925b/section/d2b16462-a889-47fc-aa04-92517825b186/day/da82d65f-2261-4bcb-87bb-71e6a7e565f5/lesson/c3dfe5a7-5fe5-4df9-9501-127c9f2b4b34)
- [ ] [Método sort()](https://app.betrybe.com/learn/course/5e938f69-6e32-43b3-9685-c936530fd326/module/94d0e996-1827-4fbc-bc24-c99fb592925b/section/d2b16462-a889-47fc-aa04-92517825b186/day/8bcc6393-e0d4-4280-ae0a-ca6d53a96eef/lesson/fc82742c-b1c2-4b8f-b226-2953c0a1d109)
- [ ] [Operadores lógicos](https://app.betrybe.com/learn/course/5e938f69-6e32-43b3-9685-c936530fd326/module/94d0e996-1827-4fbc-bc24-c99fb592925b/section/d2b16462-a889-47fc-aa04-92517825b186/day/8bcc6393-e0d4-4280-ae0a-ca6d53a96eef/lesson/945793ba-5b1a-4af5-b790-a2036963055b)
- [ ] [Projeção](https://app.betrybe.com/learn/course/5e938f69-6e32-43b3-9685-c936530fd326/module/94d0e996-1827-4fbc-bc24-c99fb592925b/section/d2b16462-a889-47fc-aa04-92517825b186/day/da82d65f-2261-4bcb-87bb-71e6a7e565f5/lesson/5bc8a303-2680-4bd1-a5be-a7b219d31f90)
- [ ] [Removendo documentos](https://app.betrybe.com/learn/course/5e938f69-6e32-43b3-9685-c936530fd326/module/94d0e996-1827-4fbc-bc24-c99fb592925b/section/d2b16462-a889-47fc-aa04-92517825b186/day/8bcc6393-e0d4-4280-ae0a-ca6d53a96eef/lesson/6f230ca6-68b3-4c18-b035-e42b9b02550e)
- [ ] [Atualizando documentos](https://app.betrybe.com/learn/course/5e938f69-6e32-43b3-9685-c936530fd326/module/94d0e996-1827-4fbc-bc24-c99fb592925b/section/d2b16462-a889-47fc-aa04-92517825b186/day/7fd45d41-7194-4d41-85cb-fc82db294078/lesson/499eb84e-bb47-444e-80ed-f453c6b52424)
- [ ] [Inserindo documentos](https://app.betrybe.com/learn/course/5e938f69-6e32-43b3-9685-c936530fd326/module/94d0e996-1827-4fbc-bc24-c99fb592925b/section/d2b16462-a889-47fc-aa04-92517825b186/day/da82d65f-2261-4bcb-87bb-71e6a7e565f5/lesson/48de2bd8-c98b-46fb-85e4-0c96e9692481)
- [ ] [Manipulando arrays](https://app.betrybe.com/learn/course/5e938f69-6e32-43b3-9685-c936530fd326/module/94d0e996-1827-4fbc-bc24-c99fb592925b/section/d2b16462-a889-47fc-aa04-92517825b186/day/9aa9cc0e-6e53-4986-a5fe-7b93df92375f/lesson/0263b954-c3dc-4f18-a111-d79da386da80)

### ⚠️ Importante ⚠️ 

👉 Não espere estar totalmente confortável com todos os itens para iniciar o projeto. O projeto, mais do que uma avaliação de aprendizagem, é o momento para você consolidar conhecimentos. O importante é dar o primeiro passo e começar lendo todos os requisitos para um entendimento amplo do que será feito.

👉 Leia o readme com atenção para um entendimento amplo do que será feito e comece a fazer o primeiro requisito. Se tiver alguma dificuldade em algum requisito, utilize o tópico anterior como um direcionador para sua pesquisa ao course e aos recursos adicionais.
