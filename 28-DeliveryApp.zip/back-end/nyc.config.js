module.exports = {
  include: ['src/**/*.js'],
  exclude: ['**/*.{test,spec}.js'],
};
