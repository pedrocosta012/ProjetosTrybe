module.exports = {
  rootDir: './e2e',
  testTimeout: 120000,
};
