**PRIORIDADE 5** - Coloque uma animação no carrinho quando adicionar/remover um produto.

**Observações técnicas**

**Requisito 19.**
