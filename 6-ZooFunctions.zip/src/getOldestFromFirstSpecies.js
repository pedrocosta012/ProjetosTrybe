const data = require('../data/zoo_data');

function getOldestFromFirstSpecies(id) {
  // seu código aqui
}

module.exports = getOldestFromFirstSpecies;
