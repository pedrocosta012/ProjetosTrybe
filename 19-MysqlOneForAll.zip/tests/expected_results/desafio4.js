module.exports = [
	{
		"usuario": "Ada Lovelace",
		"status_usuario": "Usuário inativo"
	},
	{
		"usuario": "Barbara Liskov",
		"status_usuario": "Usuário ativo"
	},
	{
		"usuario": "Bell Hooks",
		"status_usuario": "Usuário inativo"
	},
	{
		"usuario": "Christopher Alexander",
		"status_usuario": "Usuário inativo"
	},
	{
		"usuario": "Jorge Amado",
		"status_usuario": "Usuário inativo"
	},
	{
		"usuario": "Judith Butler",
		"status_usuario": "Usuário ativo"
	},
	{
		"usuario": "Martin Fowler",
		"status_usuario": "Usuário ativo"
	},
	{
		"usuario": "Paulo Freire",
		"status_usuario": "Usuário inativo"
	},
	{
		"usuario": "Robert Cecil Martin",
		"status_usuario": "Usuário ativo"
	},
	{
		"usuario": "Sandi Metz",
		"status_usuario": "Usuário ativo"
	}
];
