import Archetype from '../../src/Archetypes';

const r = new Archetype('', 99);
