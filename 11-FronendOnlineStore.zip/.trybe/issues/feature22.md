PRIORIDADE 5 - Da tela de detalhamento de produto, permitir alterar a quantidade daquele produto no carrinho, se ele estiver lá, com botões (-) e (+). A quantidade não pode ser negativa (veja detalhes no card).

- [Tela - Detalhamento do produto com quantidade.png](https://github.com/my-org/my-repo/tree/master/wireframes/card_09.png)

**Observações técnicas**

**Requisito 22.**
