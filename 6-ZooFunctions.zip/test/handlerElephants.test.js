const handlerElephants = require('../src/handlerElephants');

describe('Testes da função HandlerElephants', () => {});
