module.exports = {
  quantidade_planos: [{ quantidade_planos: 4 }],
  musicas_escutadas: [{ musicas_escutadas: 16 }],
  artistas_seguidos: [{ artistas_seguidos: 14 }],
  quantidade_albuns: [{ quantidade_albuns: 8 }],
  quantidade_cancoes: [{ quantidade_cancoes: 10 }],
  quantidade_usuarios: [{ quantidade_usuarios: 10 }],
  quantidade_artistas: [{ quantidade_artistas: 6 }]
}