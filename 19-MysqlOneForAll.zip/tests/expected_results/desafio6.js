module.exports = [
	{
		"faturamento_minimo": "0.00",
		"faturamento_maximo": "7.99",
		"faturamento_medio": "5.69",
		"faturamento_total": "56.92"
	}
];
