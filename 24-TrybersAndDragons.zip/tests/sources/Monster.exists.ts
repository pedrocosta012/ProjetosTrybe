import Monster from '../../src/Monster';
const m = new Monster();
