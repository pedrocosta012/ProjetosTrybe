PRIORIDADE 5 - Destacar produtos que já foram adicionados ao carrinho, diferenciando-o dos demais produtos da lista da página principal (veja os detalhes no card).

- [Tela - Listagem com destaque.png](https://github.com/my-org/my-repo/tree/master/wireframes/bonus_marked_product.png)

**Observações técnicas**

**Requisito 21.**
