module.exports = {
  desafio1: require('./desafio1'),
  desafio2: require('./desafio2'),
  desafio3: require('./desafio3'),
  desafio4: require('./desafio4'),
  desafio5: require('./desafio5'),
  desafio6: require('./desafio6'),
  desafio7: require('./desafio7'),
  desafio8: require('./desafio8'),
  desafio9: require('./desafio9'),
  desafio10: require('./desafio10'),
  desafio11: require('./desafio11'),
}