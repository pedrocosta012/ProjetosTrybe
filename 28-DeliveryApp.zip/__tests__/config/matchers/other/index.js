const toTestCoverage = require('./toTestCoverage');

expect.extend({
  toTestCoverage
});
