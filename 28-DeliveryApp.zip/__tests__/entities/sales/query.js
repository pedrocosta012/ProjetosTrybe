const query = 'SELECT id, user_id, seller_id, total_price, delivery_address, delivery_number, sale_date, status FROM sales';

module.exports = query;
