from src.models.dish import Dish  # noqa: F401, E261, E501


# Req 2
def test_dish():
    pass
