import IMotorcycle from '../../../src/Interfaces/IMotorcycle';
