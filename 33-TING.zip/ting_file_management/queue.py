from ting_file_management.abstract_queue import AbstractQueue


class Queue(AbstractQueue):
    def __init__(self):
        """Inicialize sua estrutura aqui"""

    def __len__(self):
        """Aqui irá sua implementação"""

    def enqueue(self, value):
        """Aqui irá sua implementação"""

    def dequeue(self):
        """Aqui irá sua implementação"""

    def search(self, index):
        """Aqui irá sua implementação"""
