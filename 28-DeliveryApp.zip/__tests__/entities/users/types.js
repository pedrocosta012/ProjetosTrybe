const types = [
  { columnName: 'id', columnType: 'INT' },
  { columnName: 'name', columnType: 'VARCHAR' },
  { columnName: 'email', columnType: 'VARCHAR' },
  { columnName: 'password', columnType: 'VARCHAR' },
  { columnName: 'role', columnType: 'VARCHAR' }
];

module.exports = types
