const data = require('../data/zoo_data');

function getEmployeesCoverage() {
  // seu código aqui
}

module.exports = getEmployeesCoverage;
