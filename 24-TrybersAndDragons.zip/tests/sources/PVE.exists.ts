import { PVE } from '../../src/Battle';
import Character from '../../src/Character';
import Monster from '../../src/Monster';

const pve = new PVE(new Character(''), [new Monster()]);
