from setuptools import setup

setup(
    name="project_algorithms",
    description="Projeto Agoritimos",
    setup_requires=["pytest-runner"],
    tests_require=["pytest"],
)
