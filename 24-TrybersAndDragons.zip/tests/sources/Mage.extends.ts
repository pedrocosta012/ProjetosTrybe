import Archetype, { Mage } from '../../src/Archetypes';

const x = (y: Archetype) => {

};
x(new Mage('Alex'));
