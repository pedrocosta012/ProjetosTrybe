import React, { Component } from 'react';

export default class Table extends Component {
  render() {
    return (
      <div>Table</div>
    );
  }
}
