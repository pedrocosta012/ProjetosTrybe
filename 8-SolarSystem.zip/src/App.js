import React from 'react';

class App extends React.Component {
  render() {
    return (<p>Sistema Solar</p>);
  }
}

export default App;
