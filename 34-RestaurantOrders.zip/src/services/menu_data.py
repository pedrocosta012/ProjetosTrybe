# Req 3
class MenuData:
    def __init__(self, source_path: str) -> None:
        pass
