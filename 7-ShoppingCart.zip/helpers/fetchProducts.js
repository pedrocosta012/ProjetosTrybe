const fetchProducts = () => {
  // seu código aqui
};

if (typeof module !== 'undefined') {
  module.exports = {
    fetchProducts,
  };
}
