import Race from '../../src/Races';

const r = new Race('', 99);
