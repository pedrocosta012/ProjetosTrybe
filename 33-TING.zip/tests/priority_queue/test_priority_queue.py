# from ting_file_management.priority_queue import PriorityQueue


def test_basic_priority_queueing():
    """Aqui irá sua implementação"""
