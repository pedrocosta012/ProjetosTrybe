## HEADER
0 - data-testid="header__title"
1 - data-testid="header__login_btn"
2 - data-testid="header__show_matches_btn"
3 - data-testid="header__show_classification_btn"
4 - data-testid="header__add_match_btn"

## Page of classification

5 - data-testid="score_boarding__classification"
6 - data-testid="score_boarding__team_name"
7 - data-testid="score_boarding__total_points"
8 - data-testid="score_boarding__total_games"
9 - data-testid="score_boarding__total_victories"
10 - data-testid="score_boarding__total_draws"
11 - data-testid="score_boarding__total_looses"
12 - data-testid="score_boarding__goals_favor"
13 - data-testid="score_boarding__goals_own"
14 - data-testid="score_boarding__goals_balance"
15 - data-testid="score_boarding__efficiency"

16 - data-testid="score_boarding__classification_" 
17 - data-testid="score_boarding__team_name_"  
18 - data-testid="score_boarding__total_points_"
19 - data-testid="score_boarding__total_games_"
20 - data-testid="score_boarding__total_victories_" 
21 - data-testid="score_boarding__total_draws_"
22 - data-testid="score_boarding__total_looses_"
23 - data-testid="score_boarding__goals_favor_"
24 - data-testid="score_boarding__goals_own_"
25 - data-testid="score_boarding__goals_balance_"
26 - data-testid="score_boarding__efficiency_"


## LOGIN

27 - data-testid="login__login_input"
28 - data-testid="login__password_input"
29 - data-testid="login__login_btn"
?? - data-testid="login__input_invalid_login_alert"

## JOGOS

30 - data-testid="matches__option_show_finish_matches"
?? - data-testid="matches__search_match_btn"
31 - data-testid="matches__home_team_"
32 - data-testid="matches__home_team_goals_"
33 - data-testid="matches__away_team_goals_"
34 - data-testid="matches__away_team_"
35 - data-testid="matches__match_status_"
35 - data-testid="matches__match_status_btn_"


## matches SETTINGS

36 - data-testid="insertion_matches__select_home_team"
37 - data-testid="insertion_matches__select_quantity_goals_home_team"
38 - data-testid="insertion_matches__select_quantity_goals_away_team"
39 - data-testid="insertion_matches__select_away_team"
40 - data-testid="insertion_matches__save_match_btn"
41 - data-testid="insertion_matches__edit_match_btn"
42 - data-testid="insertion_matches__finish_match_btn"