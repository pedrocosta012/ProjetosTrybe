const navigate = require("./navigate");
const snapShot = require("./snapShot");
const register = require("./register");

module.exports = {
  navigate,
  snapShot,
  register,
};
