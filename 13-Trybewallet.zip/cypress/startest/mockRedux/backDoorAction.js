const backDoorAction = (payload) => ({
  type: 'STARTEST_BACKDOOR',
  payload,
});

export default backDoorAction;
