const data = require('../data/zoo_data');

function getAnimalsOlderThan(animal, age) {
  // seu código aqui
}

module.exports = getAnimalsOlderThan;
