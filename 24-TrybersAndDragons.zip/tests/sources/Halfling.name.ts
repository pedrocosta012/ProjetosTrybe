import { Halfling } from '../../src/Races';
const h = new Halfling('Lobélia Sacola-Bolseiro', 100);
h.name;
