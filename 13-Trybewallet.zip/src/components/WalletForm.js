import React, { Component } from 'react';

export default class WalletForm extends Component {
  render() {
    return (
      <div>WalletForm</div>
    );
  }
}
