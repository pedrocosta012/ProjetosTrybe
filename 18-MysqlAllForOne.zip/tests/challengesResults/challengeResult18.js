const challengeResult18 = [
  {
    id: 91,
    supplier_id: 3,
    created_by: 2,
    submitted_date: '2006-01-14T00:00:00.000Z',
    creation_date: '2006-01-22T00:00:00.000Z',
    status_id: 2,
    expected_date: null,
    shipping_fee: '0.0000',
    taxes: '0.0000',
    payment_date: null,
    payment_amount: '0.0000',
    payment_method: null,
    notes: null,
    approved_by: 2,
    approved_date: '2006-01-22T00:00:00.000Z',
    submitted_by: 2
  }

];

module.exports = challengeResult18;
