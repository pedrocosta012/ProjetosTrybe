# from challenges.challenge_encrypt_message import encrypt_message


def test_encrypt_message():
    pass
