module.exports = [
	{
		"artista": "Elis Regina",
		"album": "Falso Brilhante"
	},
	{
		"artista": "Elis Regina",
		"album": "Vento de Maio"
	}
];
