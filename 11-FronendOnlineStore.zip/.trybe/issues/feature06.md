PRIORIDADE 2 - Como pessoa usuária, eu quero clicar em uma categoria e ver a listagem de produtos ser filtrada de acordo com os produtos daquela categoria (veja os detalhes no card).

**Observações técnicas**

**Requisito 6.** A página, agora, deve poder usar as categorias recuperadas da API para filtrar os produtos buscados. Os termos e as categorias inseridas por quem usa devem ser usados em conjunto para filtragens mais específicas.

**O que será avaliado:**

  * Filtra corretamente os produtos de uma página para exibir somente os daquela categoria
