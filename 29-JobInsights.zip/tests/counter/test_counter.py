# from src.pre_built.counter import count_ocurrences


def test_counter():
    pass
