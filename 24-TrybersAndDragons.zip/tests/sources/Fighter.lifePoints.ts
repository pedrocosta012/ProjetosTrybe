import Fighter from '../../src/Fighter';

const f = (obj: Fighter): number => {
  return obj.lifePoints;
}
