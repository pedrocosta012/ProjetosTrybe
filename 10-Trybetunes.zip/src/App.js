import React from 'react';

class App extends React.Component {
  render() {
    return (<p>TrybeTunes</p>);
  }
}

export default App;
