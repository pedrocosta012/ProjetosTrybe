const challengeResult8 = [{ A: 11, Trybe: 'de', eh: 10 }];

module.exports = challengeResult8;
