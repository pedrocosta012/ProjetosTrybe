import Character from '../../src/Character';
new Character('').archetype;
