def is_anagram(first_string, second_string):
    """Faça o código aqui."""
    raise NotImplementedError
