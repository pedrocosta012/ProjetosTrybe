module.exports = [
	{
		"usuario": "Ada Lovelace",
		"qt_de_musicas_ouvidas": 2,
		"total_minutos": "7.82"
	},
	{
		"usuario": "Barbara Liskov",
		"qt_de_musicas_ouvidas": 3,
		"total_minutos": "12.27"
	},
	{
		"usuario": "Bell Hooks",
		"qt_de_musicas_ouvidas": 1,
		"total_minutos": "3.38"
	},
	{
		"usuario": "Christopher Alexander",
		"qt_de_musicas_ouvidas": 1,
		"total_minutos": "3.38"
	},
	{
		"usuario": "Jorge Amado",
		"qt_de_musicas_ouvidas": 1,
		"total_minutos": "1.93"
	},
	{
		"usuario": "Judith Butler",
		"qt_de_musicas_ouvidas": 1,
		"total_minutos": "4.07"
	},
	{
		"usuario": "Martin Fowler",
		"qt_de_musicas_ouvidas": 1,
		"total_minutos": "4.45"
	},
	{
		"usuario": "Paulo Freire",
		"qt_de_musicas_ouvidas": 2,
		"total_minutos": "8.10"
	},
	{
		"usuario": "Robert Cecil Martin",
		"qt_de_musicas_ouvidas": 2,
		"total_minutos": "5.12"
	},
	{
		"usuario": "Sandi Metz",
		"qt_de_musicas_ouvidas": 2,
		"total_minutos": "6.98"
	}
];
