const data = require('../data/zoo_data');

function getAnimalMap(options) {
  // seu código aqui
}

module.exports = getAnimalMap;
