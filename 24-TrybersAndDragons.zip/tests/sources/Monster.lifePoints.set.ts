import Monster from '../../src/Monster';
const m = new Monster();
m.lifePoints = 10;
