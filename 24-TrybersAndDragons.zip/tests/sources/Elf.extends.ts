import Race, { Elf } from '../../src/Races';

const x = (y: Race) => {

};
x(new Elf('Lúthien', 100));
