import IVehicle from '../../../src/Interfaces/IVehicle';

const vehicleInterfaceTest: IVehicle = {
  model: 'carro',
  year: 1500,
  color: 'cor',
  buyValue: 1.500,
  doorsQty: 2,
  seatsQty: 2,
};

