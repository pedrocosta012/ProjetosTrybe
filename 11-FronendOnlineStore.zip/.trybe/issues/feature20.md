PRIORIDADE 5 - Exibir o conteúdo do carrinho num slider na lateral da tela, de forma que ele possa ser exibido e escondido através da interação com botão (veja os detalhes no card).

- [Tela - Listagem com carrinho populado.png](https://github.com/my-org/my-repo/tree/master/wireframes/bonus_slider.1.png)
- [Tela - Listagem com carrinho vazio.png](https://github.com/my-org/my-repo/tree/master/wireframes/bonus_slider.1.png)

**Observações técnicas**

**Requisito 20.**
