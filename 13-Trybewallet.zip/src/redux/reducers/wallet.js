// Esse reducer será responsável por tratar o todas as informações relacionadas as despesas
