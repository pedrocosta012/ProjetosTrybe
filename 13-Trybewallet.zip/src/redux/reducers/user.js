// Esse reducer será responsável por tratar as informações da pessoa usuária
