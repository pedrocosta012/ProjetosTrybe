import ICar from '../../../src/Interfaces/ICar';

const carInterfaceTest: ICar = {
  model: 'carro',
  year: 1500,
  color: 'cor',
  status: true,
  buyValue: 1.500,
  doorsQty: 2,
  seatsQty: 2,
};
