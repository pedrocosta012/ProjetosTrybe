const user = require("./user");
const nameGen = require("./nameGen");
const newUser = require("./newUser");

module.exports = {
  user,
  nameGen,
  newUser,
};
