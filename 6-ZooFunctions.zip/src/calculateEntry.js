const data = require('../data/zoo_data');

function countEntrants(entrants) {
  // seu código aqui
}

function calculateEntry(entrants) {
  // seu código aqui
}

module.exports = { calculateEntry, countEntrants };
