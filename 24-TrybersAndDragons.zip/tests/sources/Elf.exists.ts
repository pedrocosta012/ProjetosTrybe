import * as Races from '../../src/Races';
const e = new Races.Elf('', 100);
