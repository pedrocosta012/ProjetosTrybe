def is_palindrome_recursive(word, low_index, high_index):
    """Faça o código aqui."""
    raise NotImplementedError
