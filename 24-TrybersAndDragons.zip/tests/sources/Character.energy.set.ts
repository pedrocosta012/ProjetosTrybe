import Character from '../../src/Character';

const c = new Character('');
c.energy = {
  type_: 'mana',
  amount: 10
};
