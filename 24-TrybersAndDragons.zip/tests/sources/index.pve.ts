import { pve } from '../../src';
import { PVE } from '../../src/Battle';

const func = (p: PVE) => { };
func(pve);
