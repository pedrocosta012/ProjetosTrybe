import { PVP } from '../../src/Battle';
import Character from '../../src/Character';

const pvp = new PVP(new Character(''), new Character(''));
