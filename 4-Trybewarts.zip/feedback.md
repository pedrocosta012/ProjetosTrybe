# Este é o espaço de feedback do Projeto Trybewarts
## Aqui você e sua dupla poderão avaliar o projeto, deixar comentários, críticas, sugestões...

---

**É muito importante receber este feedback, para que possamos melhorar a qualidade do conteúdo oferecido às pessoas estudantes.**

---

### Qual nota vocês dariam para este projeto (0 à 10, sendo 0 muito ruim e 10 muito bom):

---

**Nota**: /ESCREVAM SUA NOTA AQUI/

---

### Vocês teriam alguma observação, crítica, sugestão, etc. para deixar? Aproveite este espaço para contar como foi a experiência com o projeto.

---

**Observações**: /ESCREVAM SUAS OBSERVAÇÕES AQUI/

---

**Pessoas integrantes da dupla**: /ESCREVAM SEUS NOMES AQUI/

---

## Agradecemos por cada feedback! #VQV #GoTrybe
