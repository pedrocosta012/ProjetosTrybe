from src.models.ingredient import Ingredient

INGREDIENTS = (
    Ingredient("queijo mussarela"),
    Ingredient("tomate"),
    Ingredient("farinha de trigo"),
    Ingredient("sal"),
    Ingredient("água"),
    Ingredient("presunto"),
    Ingredient("berinjela"),
)
