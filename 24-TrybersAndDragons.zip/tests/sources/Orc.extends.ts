import Race, { Orc } from '../../src/Races';

const x = (y: Race) => {

};
x(new Orc('Shagrat', 100));
