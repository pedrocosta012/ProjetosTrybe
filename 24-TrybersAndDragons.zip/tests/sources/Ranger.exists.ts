import * as Archetypes from '../../src/Archetypes';
const ranger = new Archetypes.Ranger('');
