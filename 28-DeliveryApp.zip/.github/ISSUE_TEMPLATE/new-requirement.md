---
name: New requirement
about: Utilizado para facilitar na construção da issue
title: "[FEATURE] [Nº REQUISITO] [NOME REQUISITO]"
labels: ''
assignees: ''

---

PR Relacionada [Link]()

Checklist
- [ ] Sub item do progresso
