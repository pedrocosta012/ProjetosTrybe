const query = "SELECT id, name, email, password, role FROM users";

module.exports = query;
