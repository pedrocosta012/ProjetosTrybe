import React from 'react';

class Wallet extends React.Component {
  render() {
    return <div>TrybeWallet</div>;
  }
}

export default Wallet;
