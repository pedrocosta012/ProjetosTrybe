def is_palindrome_iterative(word):
    """Faça o código aqui."""
    raise NotImplementedError
