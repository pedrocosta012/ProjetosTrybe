const query = 'SELECT sale_id, product_id, quantity FROM sales_products';

module.exports = query;
