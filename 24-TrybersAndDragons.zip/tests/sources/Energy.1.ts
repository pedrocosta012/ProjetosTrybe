import Energy from '../../src/Energy';

let x: Energy = {
  amount: 10,
  type_: 'stamina'
};
