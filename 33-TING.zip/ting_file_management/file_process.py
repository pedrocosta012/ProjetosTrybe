def process(path_file, instance):
    """Aqui irá sua implementação"""


def remove(instance):
    """Aqui irá sua implementação"""


def file_metadata(instance, position):
    """Aqui irá sua implementação"""
