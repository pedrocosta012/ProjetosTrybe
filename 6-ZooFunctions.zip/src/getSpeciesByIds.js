const data = require('../data/zoo_data');

function getSpeciesByIds(ids) {
  // seu código aqui
}

module.exports = getSpeciesByIds;
