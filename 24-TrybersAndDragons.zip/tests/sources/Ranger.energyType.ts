import * as Archetypes from '../../src/Archetypes';
const ranger = new Archetypes.Ranger('');
const result = () => ranger.energyType;
