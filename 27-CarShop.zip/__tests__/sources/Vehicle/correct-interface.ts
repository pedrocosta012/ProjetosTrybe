import IVehicle from '../../../src/Interfaces/IVehicle';

const vehicleInterfaceTest: IVehicle = {
  model: 'modelo',
  year: 202,
  color: 'color',
  buyValue: 0.000,
};

