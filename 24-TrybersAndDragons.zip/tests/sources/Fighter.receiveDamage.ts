import Fighter from '../../src/Fighter';

const f = (obj: Fighter) => {
  return obj.receiveDamage(10000);
}
