import { SimpleFighter } from '../../src/Fighter';
import Monster from '../../src/Monster';

const x = (y: SimpleFighter) => { };
x(new Monster());
