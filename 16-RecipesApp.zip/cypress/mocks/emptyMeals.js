const emptyMeals = { 'meals': null };

module.exports = emptyMeals;
