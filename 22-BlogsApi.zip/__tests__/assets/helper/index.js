module.exports = {
  checkModelFile: require('./checkModelFile'),
  checkModelName: require('./checkModelName'),
  checkPropertyExists: require('./checkPropertyExists'),
  checkSimpleAssociation: require('./checkSimpleAssociation'),
  checkThroughAssociation: require('./checkThroughAssociation'),
}