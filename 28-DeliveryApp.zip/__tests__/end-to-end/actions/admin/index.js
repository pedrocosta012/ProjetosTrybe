const register = require("./register");

module.exports = {
  register,
};
