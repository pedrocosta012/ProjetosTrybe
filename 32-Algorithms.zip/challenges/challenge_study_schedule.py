def study_schedule(permanence_period, target_time):
    """Faça o código aqui."""
    raise NotImplementedError
