module.exports = [
	{
		"nome": "ALIEN SUPERSTAR",
		"reproducoes": 1
	},
	{
		"nome": "Don’t Stop Me Now",
		"reproducoes": 1
	},
	{
		"nome": "Feeling Good",
		"reproducoes": 2
	},
	{
		"nome": "O Medo de Amar é o Medo de Ser Livre",
		"reproducoes": 1
	},
	{
		"nome": "Samba em Paris",
		"reproducoes": 1
	},
	{
		"nome": "The Bard’s Song",
		"reproducoes": 1
	},
	{
		"nome": "VIRGO’S GROOVE",
		"reproducoes": 1
	}
];
