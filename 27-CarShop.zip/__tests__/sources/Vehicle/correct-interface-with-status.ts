import IVehicle from '../../../src/Interfaces/IVehicle';

const vehicleInterfaceTestWhit: IVehicle = {
  model: 'modelo',
  year: 202,
  color: 'color',
  status: true,
  buyValue: 0.000,
};;
