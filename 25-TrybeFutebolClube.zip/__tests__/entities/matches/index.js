const allMatches = require('./allMatches');
const onlyInProgress = require('./onlyInProgress');
const onlyFinished = require('./onlyFinished');

module.exports = {
  allMatches,
  onlyInProgress,
  onlyFinished,
};
