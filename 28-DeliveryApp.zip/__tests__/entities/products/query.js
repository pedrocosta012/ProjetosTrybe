const query = 'SELECT id, name, price, url_image FROM products;';

module.exports = query;
