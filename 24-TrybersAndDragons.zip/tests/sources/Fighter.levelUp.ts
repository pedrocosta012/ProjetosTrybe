import Fighter from '../../src/Fighter';

const f = (obj: Fighter) => {
  return obj.levelUp();
}
