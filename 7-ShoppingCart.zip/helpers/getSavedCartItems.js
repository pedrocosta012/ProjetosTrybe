const getSavedCartItems = () => {
  // seu código aqui
};

if (typeof module !== 'undefined') {
  module.exports = getSavedCartItems;
}
