module.exports.getId = () => window.Cypress.cy.id;
