module.exports = [
	{
		"nome_musica": "The Bard’s Song",
		"novo_nome": "The QA’s Song"
	},
	{
		"nome_musica": "O Medo de Amar é o Medo de Ser Livre",
		"novo_nome": "O Medo de Code Review é o Medo de Ser Livre"
	},
	{
		"nome_musica": "Como Nossos Pais",
		"novo_nome": "Como Nossos Pull Requests"
	},
	{
		"nome_musica": "BREAK MY SOUL",
		"novo_nome": "BREAK MY CODE"
	},
	{
		"nome_musica": "ALIEN SUPERSTAR",
		"novo_nome": "ALIEN SUPERDEV"
	}
];
