import IVehicle from '../../../src/Interfaces/IVehicle';
