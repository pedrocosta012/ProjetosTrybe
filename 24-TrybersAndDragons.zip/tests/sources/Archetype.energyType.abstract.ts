import Archetype from '../../src/Archetypes';

class ArchetypeChild extends Archetype { }
