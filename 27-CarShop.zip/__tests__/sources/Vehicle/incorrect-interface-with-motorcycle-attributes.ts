import IVehicle from '../../../src/Interfaces/IVehicle';

const vehicleInterfaceTest: IVehicle = {
  model: 'moto',
  year: 1500,
  color: 'cor',
  status: true,
  buyValue: 1.500,
  category: 'Street',
  engineCapacity: 1500,
};
