def find_duplicate(nums):
    """Faça o código aqui."""
    raise NotImplementedError
