import React from 'react';

function App() {
  return <div>Hello, TrybeWallet!</div>;
}

export default App;
