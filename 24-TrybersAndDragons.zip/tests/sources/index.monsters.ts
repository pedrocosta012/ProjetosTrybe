import { monster1, monster2 } from '../../src';
import Dragon from '../../src/Dragon';
import Monster from '../../src/Monster';

const func = (monsters: Monster[]) => { };
const func2 = (dragon: Dragon) => { };
func([monster1, monster2]);
func2(monster2);
