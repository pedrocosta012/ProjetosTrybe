const goatMeals = {
  'meals': [
    {
      'strMeal': 'Mbuzi Choma (Roasted Goat)',
      'strMealThumb': 'https://www.themealdb.com/images/media/meals/cuio7s1555492979.jpg',
      'idMeal': '52968'
    }
  ],
};

module.exports = goatMeals;
