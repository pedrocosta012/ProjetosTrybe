module.exports = [
	{
		"artista": "Beyoncé",
		"album": "Renaissance",
		"seguidores": 3
	},
	{
		"artista": "Elis Regina",
		"album": "Falso Brilhante",
		"seguidores": 3
	},
	{
		"artista": "Elis Regina",
		"album": "Vento de Maio",
		"seguidores": 3
	},
	{
		"artista": "Nina Simone",
		"album": "I Put A Spell On You",
		"seguidores": 3
	},
	{
		"artista": "Queen",
		"album": "Hot Space",
		"seguidores": 3
	},
	{
		"artista": "Queen",
		"album": "Jazz",
		"seguidores": 3
	},
	{
		"artista": "Baco Exu do Blues",
		"album": "QVVJFA?",
		"seguidores": 1
	},
	{
		"artista": "Blind Guardian",
		"album": "Somewhere Far Beyond",
		"seguidores": 1
	}
];
