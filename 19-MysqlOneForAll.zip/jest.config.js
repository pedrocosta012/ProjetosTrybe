module.exports = {
  verbose: true,
  testTimeout: 1000000,
  rootDir: './tests',
  testSequencer: './assets/sequencer.js',
  testRegex: './*\\.spec\\.js$',
};
