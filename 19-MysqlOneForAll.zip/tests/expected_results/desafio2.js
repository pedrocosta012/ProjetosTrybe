module.exports = [
	{
		"cancoes": 10,
		"artistas": 6,
		"albuns": 8
	}
];
