const saveCartItems = () => {
  // seu código aqui
};

if (typeof module !== 'undefined') {
  module.exports = saveCartItems;
}
