const test01 = [
  {
    id: 1,
    password: "--adm2@21!!--",
  },
  {
    id: 2,
    password: "fulana@123",
  },
  {
    id: 3,
    password: "$#zebirita#$",
  },
];

module.exports = test01;
