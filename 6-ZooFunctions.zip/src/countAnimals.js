const data = require('../data/zoo_data');

function countAnimals(animal) {
  // seu código aqui
}

module.exports = countAnimals;
