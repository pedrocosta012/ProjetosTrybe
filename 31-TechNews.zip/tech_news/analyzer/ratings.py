# Requisito 10
def top_5_categories():
    """Seu código deve vir aqui"""
