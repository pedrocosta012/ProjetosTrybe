import Archetype, { Ranger } from '../../src/Archetypes';

const x = (y: Archetype) => {

};
x(new Ranger('Ramon'));