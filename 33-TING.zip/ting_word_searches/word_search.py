def exists_word(word, instance):
    """Aqui irá sua implementação"""


def search_by_word(word, instance):
    """Aqui irá sua implementação"""
